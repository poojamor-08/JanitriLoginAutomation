package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginPage {
    WebDriver driver;

    @FindBy(id = "user_id")
    WebElement userIdInput;

    @FindBy(id = "password")
    WebElement passwordInput;

    @FindBy(tagName = "button")
    WebElement loginButton;

    @FindBy(css = "svg[data-testid='VisibilityOffIcon'], svg[data-testid='VisibilityIcon']")
    WebElement togglePasswordIcon;

    @FindBy(className = "MuiAlert-message")
    WebElement errorMsg;

    public LoginPage(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public boolean isLoginButtonEnabled() {
        return loginButton.isEnabled();
    }

    public void enterCredentials(String user, String pass) {
        userIdInput.sendKeys(user);
        passwordInput.sendKeys(pass);
    }

    public void clickLogin() {
        loginButton.click();
    }

    public void togglePasswordVisibility() {
        togglePasswordIcon.click();
    }

    public String getErrorMessage() {
        return errorMsg.getText();
    }

    public boolean isUserIdPresent() {
        return userIdInput.isDisplayed();
    }

    public boolean isPasswordPresent() {
        return passwordInput.isDisplayed();
    }

    public boolean isEyeIconPresent() {
        return togglePasswordIcon.isDisplayed();
    }
}
