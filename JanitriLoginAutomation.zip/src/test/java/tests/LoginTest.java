package tests;

import base.BaseTest;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.LoginPage;

public class LoginTest extends BaseTest {

    @Test
    public void testLoginButtonDisabledWhenFieldsAreEmpty() {
        LoginPage login = new LoginPage(driver);
        Assert.assertFalse(login.isLoginButtonEnabled(), "Login button should be disabled when fields are empty.");
    }

    @Test
    public void testPasswordMaskedButton() {
        LoginPage login = new LoginPage(driver);
        login.togglePasswordVisibility();
        Assert.assertTrue(login.isEyeIconPresent(), "Password toggle icon should be present.");
    }

    @Test
    public void testInvalidLoginShowErrorMsg() throws InterruptedException {
        LoginPage login = new LoginPage(driver);
        login.enterCredentials("wronguser", "wrongpass");
        login.clickLogin();
        Thread.sleep(2000);
        Assert.assertTrue(login.getErrorMessage().length() > 0, "Error message should appear on invalid login.");
        System.out.println("Error Message: " + login.getErrorMessage());
    }

    @Test
    public void testPresenceOfPageElements() {
        LoginPage login = new LoginPage(driver);
        Assert.assertTrue(login.isUserIdPresent(), "User ID field should be visible");
        Assert.assertTrue(login.isPasswordPresent(), "Password field should be visible");
        Assert.assertTrue(login.isEyeIconPresent(), "Password visibility toggle should be visible");
    }
}
